# GESTURA AI V5

A Windows desktop gesture-control application using PySide6, MediaPipe Tasks, OpenCV and PyAutoGUI.

## Requirements
- Windows 10/11
- Python 3.11–3.14 (MediaPipe wheel availability depends on Python version)
- Webcam
- `hand_landmarker.task` model file

## Setup
1. Copy your existing `hand_landmarker.task` into the same folder as `main.py`.
2. Open this folder in VS Code.
3. Open a Command Prompt terminal.
4. Run:

```cmd
python -m venv venv
venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
python main.py
```

If you already have a working MediaPipe/Python environment for your previous GESTURA project, you can use that environment too.

## Controls
- Open hand: move cursor
- Thumb + index pinch: left click on release
- Hold thumb + index pinch: drag and drop
- Thumb + middle pinch: right click
- Index finger only: scroll
- Fist: pause/resume
- Start/Stop buttons: control the engine from the dashboard

## Safety
Test in Notepad or another harmless application first. PyAutoGUI fail-safe is enabled: moving the pointer to the top-left screen corner triggers its emergency stop. Use the Stop button to stop the camera and gesture engine.

## Notes
- Keep `hand_landmarker.task` beside `main.py`.
- Camera index is set to 0 in `core/gesture_engine.py`.
- This is a starter desktop release. The gesture engine runs in a background thread so the UI stays responsive.
