import os

from PySide6.QtCore import Qt
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QFrame, QLabel, QPushButton, QVBoxLayout,
    QHBoxLayout, QGridLayout, QSlider, QMessageBox, QSizePolicy
)

from core.gesture_engine import GestureWorker


APP_STYLE = """
QMainWindow, QWidget {
    background: #0b1020;
    color: #e8eefc;
    font-family: Segoe UI;
    font-size: 10pt;
}
QFrame#Sidebar {
    background: #0e1629;
    border-right: 1px solid #1d2a43;
}
QFrame#Panel {
    background: #111b30;
    border: 1px solid #20304c;
    border-radius: 16px;
}
QLabel#Brand {
    font-size: 17pt;
    font-weight: 800;
    color: #f4f7ff;
}
QLabel#Muted {
    color: #8ea1c3;
}
QLabel#PageTitle {
    font-size: 23pt;
    font-weight: 750;
    color: #f4f7ff;
}
QLabel#Metric {
    font-size: 19pt;
    font-weight: 750;
    color: #f4f7ff;
}
QPushButton {
    background: #192743;
    color: #dce7ff;
    border: 1px solid #2a3d60;
    border-radius: 10px;
    padding: 11px 15px;
    font-weight: 600;
}
QPushButton:hover {
    background: #223657;
    border-color: #4c82e8;
}
QPushButton#Primary {
    background: #3478f6;
    color: white;
    border: 1px solid #4b8aff;
}
QPushButton#Primary:hover {
    background: #4b89ff;
}
QPushButton#Danger {
    background: #38202b;
    color: #ffb7c6;
    border: 1px solid #653044;
}
QSlider::groove:horizontal {
    height: 6px;
    background: #263653;
    border-radius: 3px;
}
QSlider::sub-page:horizontal {
    background: #4c8dff;
    border-radius: 3px;
}
QSlider::handle:horizontal {
    background: #eaf2ff;
    width: 15px;
    margin: -5px 0;
    border-radius: 7px;
}
"""


class Dashboard(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("GESTURA AI V5 — Smart Gesture Control")
        self.resize(1180, 760)
        self.setMinimumSize(940, 620)
        self.worker = None
        self.model_path = os.path.abspath(
            os.path.join(os.path.dirname(__file__), "..", "hand_landmarker.task")
        )
        self._build_ui()
        self.setStyleSheet(APP_STYLE)

    def _panel(self):
        panel = QFrame()
        panel.setObjectName("Panel")
        return panel

    def _build_ui(self):
        root = QWidget()
        outer = QHBoxLayout(root)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        sidebar = QFrame()
        sidebar.setObjectName("Sidebar")
        sidebar.setFixedWidth(220)
        side = QVBoxLayout(sidebar)
        side.setContentsMargins(20, 25, 18, 22)
        side.setSpacing(13)

        brand = QLabel("◈  GESTURA AI")
        brand.setObjectName("Brand")
        side.addWidget(brand)
        sub = QLabel("SMART GESTURE CONTROL")
        sub.setObjectName("Muted")
        sub.setStyleSheet("font-size: 8pt; letter-spacing: 1px;")
        side.addWidget(sub)
        side.addSpacing(25)

        nav_label = QLabel("WORKSPACE")
        nav_label.setObjectName("Muted")
        nav_label.setStyleSheet("font-size: 8pt; font-weight: 700;")
        side.addWidget(nav_label)

        self.nav_dashboard = QPushButton("▦   Dashboard")
        self.nav_dashboard.setObjectName("Primary")
        self.nav_gestures = QPushButton("✋   Gestures")
        self.nav_settings = QPushButton("⚙   Settings")
        for button in (self.nav_dashboard, self.nav_gestures, self.nav_settings):
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            side.addWidget(button)

        side.addStretch()
        version = QLabel("GESTURA AI V5.0\nLocal desktop edition")
        version.setObjectName("Muted")
        side.addWidget(version)

        content = QWidget()
        main = QVBoxLayout(content)
        main.setContentsMargins(28, 24, 28, 24)
        main.setSpacing(18)

        header = QHBoxLayout()
        heading_box = QVBoxLayout()
        eyebrow = QLabel("CONTROL CENTER  /  OVERVIEW")
        eyebrow.setObjectName("Muted")
        title = QLabel("Your gesture workspace")
        title.setObjectName("PageTitle")
        heading_box.addWidget(eyebrow)
        heading_box.addWidget(title)
        header.addLayout(heading_box)
        header.addStretch()

        self.connection_badge = QLabel("●  OFFLINE")
        self.connection_badge.setStyleSheet(
            "background:#2a2430; color:#ffbdc8; padding:9px 13px; border-radius:10px; font-weight:700;"
        )
        header.addWidget(self.connection_badge)
        main.addLayout(header)

        metrics = QGridLayout()
        metrics.setSpacing(12)
        self.status_metric = self._metric_card("ENGINE STATUS", "Stopped", "Waiting for you to start")
        self.fps_metric = self._metric_card("PROCESSING SPEED", "— FPS", "Live camera processing")
        self.gesture_metric = self._metric_card("ACTIVE GESTURE", "—", "Detected in real time")
        metrics.addWidget(self.status_metric, 0, 0)
        metrics.addWidget(self.fps_metric, 0, 1)
        metrics.addWidget(self.gesture_metric, 0, 2)
        main.addLayout(metrics)

        middle = QHBoxLayout()
        middle.setSpacing(14)

        camera_panel = self._panel()
        camera_layout = QVBoxLayout(camera_panel)
        camera_layout.setContentsMargins(16, 14, 16, 16)
        camera_header = QHBoxLayout()
        camera_title = QLabel("Live camera")
        camera_title.setStyleSheet("font-size:13pt; font-weight:700;")
        camera_header.addWidget(camera_title)
        camera_header.addStretch()
        camera_tag = QLabel("●  PREVIEW")
        camera_tag.setStyleSheet("color:#77dca6; font-size:8pt; font-weight:700;")
        camera_header.addWidget(camera_tag)
        camera_layout.addLayout(camera_header)

        self.preview = QLabel("Camera preview will appear here\n\nPress  START ENGINE  to begin")
        self.preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.preview.setMinimumSize(480, 300)
        self.preview.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.preview.setStyleSheet(
            "background:#080d18; border:1px dashed #2b4165; border-radius:12px; color:#8194b5;"
        )
        camera_layout.addWidget(self.preview, 1)

        controls = QHBoxLayout()
        self.start_button = QPushButton("▶   Start engine")
        self.start_button.setObjectName("Primary")
        self.start_button.clicked.connect(self.start_engine)
        self.stop_button = QPushButton("■   Stop")
        self.stop_button.setObjectName("Danger")
        self.stop_button.setEnabled(False)
        self.stop_button.clicked.connect(self.stop_engine)
        controls.addWidget(self.start_button)
        controls.addWidget(self.stop_button)
        camera_layout.addLayout(controls)
        middle.addWidget(camera_panel, 3)

        right_col = QVBoxLayout()
        right_col.setSpacing(14)

        gesture_panel = self._panel()
        gesture_layout = QVBoxLayout(gesture_panel)
        gesture_layout.setContentsMargins(16, 15, 16, 15)
        gesture_title = QLabel("Gesture map")
        gesture_title.setStyleSheet("font-size:13pt; font-weight:700;")
        gesture_layout.addWidget(gesture_title)
        gesture_rows = [
            ("✋", "Open hand", "Move cursor"),
            ("🤏", "Thumb + index", "Left click / drag"),
            ("☝", "Thumb + middle", "Right click"),
            ("↑", "Index only", "Scroll"),
            ("✊", "Fist", "Pause / resume"),
        ]
        for icon, name, action in gesture_rows:
            row = QHBoxLayout()
            icon_label = QLabel(icon)
            icon_label.setFixedWidth(28)
            icon_label.setStyleSheet("font-size:15pt;")
            labels = QVBoxLayout()
            name_label = QLabel(name)
            name_label.setStyleSheet("font-weight:650;")
            action_label = QLabel(action)
            action_label.setObjectName("Muted")
            action_label.setStyleSheet("font-size:8pt;")
            labels.addWidget(name_label)
            labels.addWidget(action_label)
            row.addWidget(icon_label)
            row.addLayout(labels, 1)
            gesture_layout.addLayout(row)
        right_col.addWidget(gesture_panel)

        sensitivity_panel = self._panel()
        sensitivity_layout = QVBoxLayout(sensitivity_panel)
        sensitivity_layout.setContentsMargins(16, 15, 16, 15)
        sensitivity_title = QLabel("Cursor sensitivity")
        sensitivity_title.setStyleSheet("font-size:13pt; font-weight:700;")
        sensitivity_layout.addWidget(sensitivity_title)
        self.sensitivity_value = QLabel("55%")
        self.sensitivity_value.setObjectName("Muted")
        sensitivity_layout.addWidget(self.sensitivity_value)
        self.sensitivity_slider = QSlider(Qt.Orientation.Horizontal)
        self.sensitivity_slider.setRange(10, 95)
        self.sensitivity_slider.setValue(55)
        self.sensitivity_slider.valueChanged.connect(self._sensitivity_changed)
        sensitivity_layout.addWidget(self.sensitivity_slider)
        hint = QLabel("Higher = faster response\nLower = smoother movement")
        hint.setObjectName("Muted")
        hint.setStyleSheet("font-size:8pt;")
        sensitivity_layout.addWidget(hint)
        right_col.addWidget(sensitivity_panel)
        right_col.addStretch()

        middle.addLayout(right_col, 2)
        main.addLayout(middle, 1)

        footer = QLabel("Tip: Test gestures in a harmless window first. Press Q in the camera preview is not required — use Stop here.")
        footer.setObjectName("Muted")
        footer.setStyleSheet("font-size:8pt;")
        main.addWidget(footer)

        outer.addWidget(sidebar)
        outer.addWidget(content, 1)
        self.setCentralWidget(root)

        self.nav_gestures.clicked.connect(self.show_gesture_info)
        self.nav_settings.clicked.connect(self.show_settings_info)

    def _metric_card(self, label, value, hint):
        card = self._panel()
        layout = QVBoxLayout(card)
        layout.setContentsMargins(15, 13, 15, 13)
        top = QLabel(label)
        top.setObjectName("Muted")
        top.setStyleSheet("font-size:8pt; font-weight:700;")
        val = QLabel(value)
        val.setObjectName("Metric")
        desc = QLabel(hint)
        desc.setObjectName("Muted")
        desc.setStyleSheet("font-size:8pt;")
        layout.addWidget(top)
        layout.addWidget(val)
        layout.addWidget(desc)
        card.value_label = val
        card.hint_label = desc
        return card

    def _sensitivity_changed(self, value):
        self.sensitivity_value.setText(f"{value}%")
        if self.worker and self.worker.isRunning():
            self.worker.set_sensitivity(value)

    def start_engine(self):
        if self.worker and self.worker.isRunning():
            return
        self.worker = GestureWorker(self.model_path)
        self.worker.frame_ready.connect(self._update_preview)
        self.worker.status_changed.connect(self._update_status)
        self.worker.fps_changed.connect(self._update_fps)
        self.worker.error_occurred.connect(self._show_error)
        self.worker.set_sensitivity(self.sensitivity_slider.value())
        self.worker.start()

        self.start_button.setEnabled(False)
        self.stop_button.setEnabled(True)
        self.connection_badge.setText("●  CONNECTING")
        self.connection_badge.setStyleSheet(
            "background:#292b20; color:#f5d47a; padding:9px 13px; border-radius:10px; font-weight:700;"
        )
        self.status_metric.value_label.setText("Starting…")

    def stop_engine(self):
        if self.worker:
            self.worker.stop()
            self.worker = None
        self.start_button.setEnabled(True)
        self.stop_button.setEnabled(False)
        self.connection_badge.setText("●  OFFLINE")
        self.connection_badge.setStyleSheet(
            "background:#2a2430; color:#ffbdc8; padding:9px 13px; border-radius:10px; font-weight:700;"
        )
        self.status_metric.value_label.setText("Stopped")
        self.gesture_metric.value_label.setText("—")
        self.preview.setPixmap(QPixmap())
        self.preview.setText("Camera stopped\n\nPress START ENGINE to begin")

    def _update_preview(self, image):
        pixmap = QPixmap.fromImage(image)
        self.preview.setPixmap(
            pixmap.scaled(
                self.preview.size(),
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )
        )

    def _update_status(self, status):
        self.status_metric.value_label.setText("Running" if status not in ("Stopped", "Paused") else status)
        self.gesture_metric.value_label.setText(status[:22])
        if status == "Stopped":
            self.start_button.setEnabled(True)
            self.stop_button.setEnabled(False)
            self.connection_badge.setText("●  OFFLINE")
        elif status == "Paused":
            self.connection_badge.setText("●  PAUSED")
        else:
            self.connection_badge.setText("●  ONLINE")
            self.connection_badge.setStyleSheet(
                "background:#173329; color:#86e8b2; padding:9px 13px; border-radius:10px; font-weight:700;"
            )

    def _update_fps(self, fps):
        self.fps_metric.value_label.setText(f"{fps:.0f} FPS")

    def _show_error(self, message):
        QMessageBox.critical(self, "GESTURA AI — Error", message)
        self.status_metric.value_label.setText("Error")
        self.connection_badge.setText("●  ERROR")
        self.start_button.setEnabled(True)
        self.stop_button.setEnabled(False)

    def show_gesture_info(self):
        QMessageBox.information(
            self, "Gesture map",
            "Open hand: Move cursor\nThumb + index: Left click / drag\n"
            "Thumb + middle: Right click\nIndex only: Scroll\nFist: Pause / resume"
        )

    def show_settings_info(self):
        QMessageBox.information(
            self, "Settings",
            "Adjust cursor sensitivity using the slider on the dashboard.\n"
            "More camera and gesture settings can be added in the next update."
        )

    def closeEvent(self, event):
        if self.worker and self.worker.isRunning():
            self.worker.stop()
        event.accept()
