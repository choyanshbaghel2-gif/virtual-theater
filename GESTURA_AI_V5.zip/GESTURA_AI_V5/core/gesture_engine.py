import math
import time

import cv2
import mediapipe as mp
import pyautogui
from PySide6.QtCore import QThread, Signal
from PySide6.QtGui import QImage

from mediapipe.tasks import python
from mediapipe.tasks.python import vision


class GestureWorker(QThread):
    frame_ready = Signal(QImage)
    status_changed = Signal(str)
    fps_changed = Signal(float)
    error_occurred = Signal(str)

    def __init__(self, model_path, camera_index=0, parent=None):
        super().__init__(parent)
        self.model_path = model_path
        self.camera_index = camera_index
        self._running = False
        self._paused = False
        self.sensitivity = 0.55
        self._previous_x = None
        self._previous_y = None
        self._left_pinching = False
        self._right_pinching = False
        self._dragging = False
        self._pinch_started = 0.0
        self._fist_latched = False
        self._scroll_previous_y = None
        self._last_fps_time = time.perf_counter()
        self._fps_frames = 0

        # Keep the global fail-safe enabled. Move the pointer to the
        # top-left screen corner for PyAutoGUI's emergency stop.
        pyautogui.FAILSAFE = True
        pyautogui.PAUSE = 0

    def set_paused(self, paused):
        self._paused = bool(paused)
        if self._paused:
            self._release_mouse()
            self.status_changed.emit("Paused")

    def set_sensitivity(self, value):
        self.sensitivity = max(0.10, min(0.95, float(value) / 100.0))

    def _release_mouse(self):
        if self._dragging:
            try:
                pyautogui.mouseUp()
            except Exception:
                pass
        self._dragging = False
        self._left_pinching = False
        self._right_pinching = False

    @staticmethod
    def _dist(a, b):
        return math.hypot(a[0] - b[0], a[1] - b[1])

    @staticmethod
    def _point(hand, idx, width, height):
        p = hand[idx]
        return int(p.x * width), int(p.y * height)

    @staticmethod
    def _finger_extended(hand, tip_id, pip_id):
        wrist = hand[0]
        tip = hand[tip_id]
        pip = hand[pip_id]
        tip_d = math.hypot(tip.x - wrist.x, tip.y - wrist.y)
        pip_d = math.hypot(pip.x - wrist.x, pip.y - wrist.y)
        return tip_d > pip_d * 1.12

    def _move_cursor(self, hand, width, height):
        index = hand[8]
        frame_x, frame_y = 30, 30
        x = (index.x * width - frame_x) / max(1, width - frame_x * 2)
        y = (index.y * height - frame_y) / max(1, height - frame_y * 2)
        x = max(0.0, min(1.0, x))
        y = max(0.0, min(1.0, y))

        screen_w, screen_h = pyautogui.size()
        target_x = int(x * (screen_w - 1))
        target_y = int(y * (screen_h - 1))

        if self._previous_x is None:
            self._previous_x, self._previous_y = target_x, target_y

        alpha = self.sensitivity
        self._previous_x += (target_x - self._previous_x) * alpha
        self._previous_y += (target_y - self._previous_y) * alpha
        pyautogui.moveTo(int(self._previous_x), int(self._previous_y), _pause=False)

    @staticmethod
    def _draw_hand(frame, hand):
        h, w = frame.shape[:2]
        pts = [
            (int(p.x * w), int(p.y * h))
            for p in hand
        ]
        connections = vision.HandLandmarksConnections.HAND_CONNECTIONS
        for connection in connections:
            cv2.line(
                frame, pts[connection.start], pts[connection.end],
                (60, 220, 130), 2, cv2.LINE_AA
            )
        for i, pt in enumerate(pts):
            color = (255, 190, 65) if i == 8 else (80, 180, 255)
            cv2.circle(frame, pt, 4 if i == 8 else 2, color, -1)

    def run(self):
        detector = None
        cap = None
        try:
            if not self.model_path or not __import__("os").path.isfile(self.model_path):
                self.error_occurred.emit(
                    "hand_landmarker.task was not found. Keep it in the GESTURA_AI_V5 folder."
                )
                return

            base_options = python.BaseOptions(model_asset_path=self.model_path)
            options = vision.HandLandmarkerOptions(
                base_options=base_options,
                running_mode=vision.RunningMode.VIDEO,
                num_hands=1,
                min_hand_detection_confidence=0.5,
                min_hand_presence_confidence=0.5,
                min_tracking_confidence=0.5,
            )
            detector = vision.HandLandmarker.create_from_options(options)

            cap = cv2.VideoCapture(self.camera_index, cv2.CAP_DSHOW)
            cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
            cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
            cap.set(cv2.CAP_PROP_FPS, 30)
            cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)

            if not cap.isOpened():
                self.error_occurred.emit("Could not open webcam. Check that it is connected and not in use.")
                return

            self._running = True
            timestamp_ms = 0
            self.status_changed.emit("Camera connected — show your hand")

            while self._running:
                ok, frame = cap.read()
                if not ok:
                    self.status_changed.emit("Waiting for camera frame…")
                    self.msleep(10)
                    continue

                frame = cv2.flip(frame, 1)
                h, w = frame.shape[:2]
                timestamp_ms = max(timestamp_ms + 1, time.monotonic_ns() // 1_000_000)

                rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)
                result = detector.detect_for_video(mp_image, timestamp_ms)
                status = "Show your hand"

                if result.hand_landmarks:
                    hand = result.hand_landmarks[0]
                    self._draw_hand(frame, hand)

                    thumb = self._point(hand, 4, w, h)
                    index = self._point(hand, 8, w, h)
                    middle = self._point(hand, 12, w, h)

                    index_up = self._finger_extended(hand, 8, 6)
                    middle_up = self._finger_extended(hand, 12, 10)
                    ring_up = self._finger_extended(hand, 16, 14)
                    pinky_up = self._finger_extended(hand, 20, 18)

                    fist = not (index_up or middle_up or ring_up or pinky_up)

                    palm_size = max(
                        1,
                        self._dist(
                            self._point(hand, 0, w, h),
                            self._point(hand, 9, w, h),
                        ),
                    )
                    pinch_threshold = max(18, palm_size * 0.28)
                    release_threshold = max(28, palm_size * 0.42)
                    index_distance = self._dist(thumb, index)
                    middle_distance = self._dist(thumb, middle)
                    left_active = index_distance < pinch_threshold
                    right_active = middle_distance < pinch_threshold

                    if fist and not self._fist_latched:
                        self._paused = not self._paused
                        self._fist_latched = True
                        self._release_mouse()
                        status = "Paused" if self._paused else "Resumed"
                    if not fist:
                        self._fist_latched = False

                    if self._paused:
                        status = "Paused"
                        self._scroll_previous_y = None
                    else:
                        scroll_mode = (
                            index_up and not middle_up and not ring_up and not pinky_up
                            and not left_active and not right_active and not self._dragging
                        )

                        # Left click / hold to drag. Click is sent on pinch release.
                        if left_active and not right_active:
                            if not self._left_pinching:
                                self._left_pinching = True
                                self._pinch_started = time.monotonic()
                            if time.monotonic() - self._pinch_started >= 0.45:
                                if not self._dragging:
                                    pyautogui.mouseDown()
                                    self._dragging = True
                                status = "Dragging"
                            else:
                                status = "Left click — hold to drag"
                        elif self._left_pinching:
                            if self._dragging:
                                pyautogui.mouseUp()
                                self._dragging = False
                                status = "Dropped"
                            else:
                                pyautogui.click()
                                status = "Left click"
                            self._left_pinching = False

                        # Right click once per pinch.
                        if right_active and not left_active:
                            if not self._right_pinching:
                                pyautogui.click(button="right")
                                self._right_pinching = True
                                status = "Right click"
                        elif middle_distance > release_threshold:
                            self._right_pinching = False

                        if scroll_mode:
                            current_y = hand[8].y
                            if self._scroll_previous_y is not None:
                                movement = self._scroll_previous_y - current_y
                                if abs(movement) > 0.012:
                                    amount = int(movement * 300)
                                    if amount:
                                        pyautogui.scroll(amount)
                            self._scroll_previous_y = current_y
                            status = "Scroll mode"
                        else:
                            self._scroll_previous_y = None

                        # Cursor keeps tracking while pinching any finger.
                        # It pauses only for fist, scrolling, dragging or app pause.
                        cursor_mode = not fist and not self._paused and not self._dragging and not scroll_mode
                        if cursor_mode:
                            self._move_cursor(hand, w, h)
                            if left_active:
                                status = "Left click gesture"
                            elif right_active:
                                status = "Right click gesture"
                            else:
                                status = "Cursor active"
                else:
                    self._left_pinching = False
                    self._right_pinching = False
                    self._scroll_previous_y = None
                    if self._dragging:
                        pyautogui.mouseUp()
                        self._dragging = False
                    status = "No hand detected"

                # Minimal status strip in the preview.
                cv2.rectangle(frame, (0, 0), (w, 42), (18, 25, 39), -1)
                cv2.putText(
                    frame, f"GESTURA AI  |  {status}",
                    (12, 27), cv2.FONT_HERSHEY_SIMPLEX,
                    0.62, (235, 242, 255), 2, cv2.LINE_AA
                )

                rgb_display = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                qimage = QImage(
                    rgb_display.data, w, h, 3 * w, QImage.Format.Format_RGB888
                ).copy()
                self.frame_ready.emit(qimage)
                self.status_changed.emit(status)

                self._fps_frames += 1
                now = time.perf_counter()
                elapsed = now - self._last_fps_time
                if elapsed >= 1.0:
                    self.fps_changed.emit(self._fps_frames / elapsed)
                    self._fps_frames = 0
                    self._last_fps_time = now

        except pyautogui.FailSafeException:
            self.status_changed.emit("Safety stop activated")
        except Exception as exc:
            self.error_occurred.emit(f"{type(exc).__name__}: {exc}")
        finally:
            self._running = False
            self._release_mouse()
            if cap is not None:
                cap.release()
            if detector is not None:
                detector.close()
            self.status_changed.emit("Stopped")

    def stop(self):
        self._running = False
        self.wait(2500)
